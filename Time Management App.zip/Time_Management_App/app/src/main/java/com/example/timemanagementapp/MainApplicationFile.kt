package com.example.timemanagementapp

import android.app.Application
import android.content.Intent
import androidx.appcompat.app.AppCompatDelegate
import com.example.timemanagementapp.activities.LoginPage
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class MainApplicationFile : Application() {

}
