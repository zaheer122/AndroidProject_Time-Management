package com.example.timemanagementapp.structure_data_class


data class StructureStopWatch(
    var id: Int?,
    val time: String,
    var work: String,
    var description: String?
)