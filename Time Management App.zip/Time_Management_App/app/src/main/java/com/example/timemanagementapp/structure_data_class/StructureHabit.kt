package com.example.timemanagementapp.structure_data_class

data class StructureHabit(
    var id: Int?,
    var habitName: String?,
    var habitProgress: String?,
    var habitStreak: String?
)
